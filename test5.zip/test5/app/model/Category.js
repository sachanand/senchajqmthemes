Ext.define('test5.model.Category',{
	
	extend:'Ext.data.Model',
	
	config: {
		fields:['name','questions']
	
	}

});