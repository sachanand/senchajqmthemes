Ext.define('test5.view.Home', {
    extend: 'Ext.Panel',
    xtype: 'home',

    config: {
	
		title:'Home',
		iconCls:'home'
    }
});